//
//  Homepage.swift
//  FINAL UDROP
//

import Foundation
import UIKit
//import Drop.swift

let Friends = AllUsersTableViewCell()
let AddDrop = Drop(coder: <#NSCoder#>)
let Profile = SettingsViewController()

func scrollView() -> UIScrollView {
        let view = UIScrollView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.contentMode = .scaleAspectFill
        return view
}

/*class RootViewController: UIViewController{
    
    var scrollView;() -> UIScrollView = {
        let view = UIScrollView()
    return view
}
    var MyDrops: UIlabel = {
    let MyDrops = UILabel()
        return MyDrops
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    view.addSubview(scrollView)
    }*/


