//
//  globals.swift
//  regionTest


import Foundation
/*
class : <#super class#> {
    <#code#>
}
var drops: [Drop] = []

*/
/Users/kelseyburgos/Desktop/FINAL UDROP/FINAL UDROP/Homepage.swift
