//
//  MultiColorCircleOverlay.swift
//  VEXTit Drop

import UIKit
import MapKit

class MultiColorCircleOverlay: MKCircle {

    var colorChoiceTag: Int?
}
